import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Tamanna Sood</h1>
    <h2>
      {' '}
      <a href="mailto:tsood@usc.edu">tsood@usc.edu</a>
    </h2>
    <div id="fav-color" className="align">
      <h3> My favorite color is Pink!</h3>
    </div>
    <div id="fav-site" className="align">
      <h4>
        My favorite website is <a href="https://twitter.com/">Twitter!</a>
      </h4>
    </div>
    <div id="fav-activity" className="align">
      <h4>My favorite activity is cooking!</h4>
      <img src="https://gifdb.com/images/high/peach-bear-cooking-ahw9iiubzywut9jh.gif" />
    </div>

    <div id="schedule" className="align">
      <h4>Schedule</h4>
      <ul>
        <li>ITP-301: Front-End Web Development</li>
        <li>WRIT 340: Advanced Writing</li>
        <li>CTPR 474: Documentary Production</li>
        <li>JOUR 462: Law of Mass Communication</li>
      </ul>
    </div>
  </React.StrictMode>
);
