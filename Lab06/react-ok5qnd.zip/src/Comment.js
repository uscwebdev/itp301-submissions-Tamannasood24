import React from 'react';

export default function Comment(props) {
  return (
    <div className="Comment">
      <img src={props.src} alt="this is a clipart image of a profile picture" />
      <p className="username">{props.username}</p>
      <p className="date">{props.date}</p>
      <p className="text">{props.text}</p>
    </div>
  );
}
