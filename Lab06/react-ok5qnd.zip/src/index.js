import React from 'react';
import { createRoot } from 'react-dom/client';
import Comment from './Comment.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>My favorite Dog Breeds!</h1>

    <div className="row">
      <h2>
        <a href="https://www.akc.org/dog-breeds/american-staffordshire-terrier/">
          1. Pitbull
        </a>
      </h2>
      <img
        src="https://media-be.chewy.com/wp-content/uploads/2021/06/11164440/American-Pit-Bull-terrier-1143880146-951x615.jpg"
        alt="This is an image of a pitbull."
      />
      <p>
        Pitbulls are extremely adoring breeds that often get a bad rep because
        of a the actions of bad owners. Pitbulls are actually ranked as the 4th
        most genle breed by the American Temperament Test society. Along with
        being a great family dog, Pitbulls are loyal and kind companions.{' '}
      </p>
    </div>

    <div className="row">
      <h2>
        <a href="https://www.akc.org/dog-breeds/german-shepherd-dog/">
          {' '}
          2. German Shepherd{' '}
        </a>{' '}
      </h2>
      <img
        src="https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8Z2VybWFuJTIwc2hlcGhlcmQlMjBkb2d8ZW58MHx8MHx8fDA%3D&w=1000&q=80"
        alt="This is an image of a German shepherd."
      />
      <p>
        Being cute goes without being said about German Shepherds, but, they are
        also extremely smart and are great dogs for active people. They have
        unqiue personalities that are perfect for all sorts of jobs including
        search and recuse missions to being great service animals.
      </p>
    </div>

    <div className="row">
      <h2>
        {' '}
        <a href="https://www.akc.org/dog-breeds/australian-shepherd/">
          {' '}
          3. Australian Shepherd{' '}
        </a>{' '}
      </h2>
      <img
        src="https://media.istockphoto.com/id/1361385088/photo/aussie-puppy-in-fresh-air-young-thoroughbred-dog-australian-shepherd-puppy-red-merle-with.jpg?s=612x612&w=0&k=20&c=6ARee_bBGqGCCqxtUO07njqZ_pcm4Yquy9E4TPmk1IM="
        alt="This is an image of an Australian Shepherd."
      />
      <p>
        {' '}
        I am biased towards them because my roommate has one and he's the cutest
        guy in the world. Australian shepherds are extrmely charismatic and
        smart dogs. They ofen mimic the personality of their owners and have a
        great nose for treats!
      </p>
    </div>

    <h3> Comments</h3>
    <Comment
      src="https://img.freepik.com/premium-vector/woman-profile-cartoon_18591-58477.jpg?w=2000"
      username="DogLuver81"
      date="8/23/23"
      text=" My favorite dog breeds are Golden Retriver and Basset Hounds!"
    />

    <Comment
      src="https://img.freepik.com/premium-vector/woman-profile-cartoon_18591-58480.jpg"
      username="CatLuver626"
      date="8/20/23"
      text="Dogs are gross! Cats are the best!"
    />
    <Comment
      src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWUjwEv0oJkIAEHu_JVOgpQxcCB4tmACQEVwFYlQn-CCswqmz2-A8Sjfo_bjU1HqLuJ08&usqp=CAU"
      username="PibullsRBest"
      date="9/1/23"
      text="Your first choice is perfect!"
    />

    <Comment
      src="https://img.freepik.com/premium-vector/man-profile-cartoon_18591-58484.jpg?w=2000"
      username="Look4Dawg"
      date="9/21/23"
      text="This was really helpful! I think I'm gonna get an Australian Shepherd."
    />

    {/* <div className="Comment">
      {' '}
      <img
        src="https://img.freepik.com/premium-vector/woman-profile-cartoon_18591-58477.jpg?w=2000"
        alt="this is a clipart image of a profile picture"
      />{' '}
      <p className="username">DogLuver81</p>
      <p className="date"> 8/23/23 </p>
      <p className="text">
        My favorite dog breeds are Golden Retriver and Basset Hounds!
      </p>
    </div>

    <div className="Comment">
      {' '}
      <img
        src="https://img.freepik.com/premium-vector/woman-profile-cartoon_18591-58480.jpg"
        alt="this is a clipart image of a profile picture"
      />{' '}
      <p className="username">CatLuver626</p>
      <p className="date"> 8/20/23 </p>
      <p className="text">Dogs are gross! Cats are the best!</p>
    </div>

    <div className="Comment">
      {' '}
      <img
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWUjwEv0oJkIAEHu_JVOgpQxcCB4tmACQEVwFYlQn-CCswqmz2-A8Sjfo_bjU1HqLuJ08&usqp=CAU"
        alt="this is a clipart image of a profile picture"
      />{' '}
      <p className="username">PibullsRBest</p>
      <p className="date"> 9/1/23 </p>
      <p className="text">Your first choice is perfect!</p>
    </div>

    <div className="Comment">
      {' '}
      <img
        src="https://img.freepik.com/premium-vector/man-profile-cartoon_18591-58484.jpg?w=2000"
        alt="this is a clipart image of a profile picture"
      />{' '}
      <p className="username">Look4Dawg</p>
      <p className="date"> 9/21/23 </p>
      <p className="text">
        This was really helpful! I think I'm gonna get an Australian Shepherd.
      </p>
    </div> */}
  </React.StrictMode>
);
