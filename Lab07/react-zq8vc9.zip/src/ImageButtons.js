import React from 'react';
import { useState } from 'react';

export default function ImageButtons(props) {
  const [src, setSrc] = useState(
    'https://i.pinimg.com/736x/ee/54/1e/ee541ee1ac3b75f07db0b97e8c0d34af.jpg'
  );

  const [alt, setAlt] = useState(
    'This is an image of the symbol of airbending from the show Avatar: The Last Airbender.'
  );
  const [caption, setCaption] = useState('Airbending');
  function handleImageChange(newSrc, newAlt, newCaption) {
    console.log('Button clicked');
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  }

  return (
    <div id="buttons">
      <button
        id="one"
        onClick={() => {
          handleImageChange(
            'https://i.pinimg.com/736x/ee/54/1e/ee541ee1ac3b75f07db0b97e8c0d34af.jpg',
            'This is an image of the symbol of airbending from the show Avatar: The Last Airbender.',
            'Airbending'
          );
        }}
      >
        Image 1
      </button>

      <button
        id="two"
        onClick={() => {
          handleImageChange(
            'https://i.pinimg.com/originals/03/fb/0d/03fb0d6ec891f0dbf64f36bc720d0a11.jpg',
            'This is an image of the symbol of waterbending from the show Avatar: The Last Airbender.',
            'Waterbending'
          );
        }}
      >
        Image 2
      </button>

      <button
        id="three"
        onClick={() => {
          handleImageChange(
            'https://i.pinimg.com/originals/ec/22/05/ec220545e4d35ecac052c2d3413d2bc9.jpg',
            'This is an image of the symbol of earthbending from the show Avatar: The Last Airbender.',
            'Earthbending'
          );
        }}
      >
        Image 3
      </button>

      <button
        id="four"
        onClick={() => {
          handleImageChange(
            'https://i.pinimg.com/originals/aa/bd/bc/aabdbca6d01d7301e0059cd00c11d026.jpg',
            'This is an image of the symbol of firebending from the show Avatar: The Last Airbender.',
            'Firebending'
          );
        }}
      >
        Image 4
      </button>

      <button
        id="five"
        onClick={() => {
          handleImageChange(
            'https://i.pinimg.com/564x/e2/3b/bf/e23bbf3ed4e5d08325136b1909d593f6.jpg',
            'This is an image of all of symbol of bending from the show Avatar: The Last Airbender.',
            'All bending symbols'
          );
        }}
      >
        Image 5
      </button>

      <img id="main" src={src} alt={alt} />
      <p id="caption">{caption}</p>
    </div>
  );
}
