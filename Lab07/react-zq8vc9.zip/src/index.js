import React from 'react';
import { createRoot } from 'react-dom/client';
import ImageButtons from './ImageButtons.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="button_container">
      <h1> Types of Bending from Avatar the Last Air Bender Gallery! </h1>
      <ImageButtons />
    </div>
  </React.StrictMode>
);
