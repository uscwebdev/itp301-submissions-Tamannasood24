import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comment, setComment] = useState('');
  const [terms, setTerms] = useState(false);

  const [usernameError, setUsernameError] = useState();
  const [passwordError, setPasswordError] = useState();
  const [confirmError, setConfirmError] = useState();
  const [emailError, setEmailError] = useState();
  const [commentError, setCommentError] = useState();
  const [termError, setTermError] = useState();

  function handleSubmit(e) {
    e.preventDefault();
    var foundError = false;

    if (username.length === 0) {
      foundError = true;
      setUsernameError('Name cannot be empty.');
    } else if (username.indexOf(' ') === -1) {
      foundError = true;
      setUsernameError('You must provide a full name.');
    } else {
      setUsernameError('');
    }

    if (foundError == true) {
      e.preventDefault();
    } else {
      alert('Registration Successful.');
    }

    if (password.length === 0) {
      foundError = true;
      setPasswordError('Password cannot be empty');
    } else if (
      password === password.toLowerCase() ||
      password === password.toUpperCase()
    ) {
      foundError = true;
      setPasswordError('Password must contain lower AND uppercase letters.');
    } else if (password < 5) {
      foundError = true;
      setPasswordError('Password must contain 5 characters.');
    } else {
      setPasswordError('');
    }

    if (confirm !== password) {
      foundError = true;
      setConfirmError('Passwords do not match.');
    } else {
      setConfirmError('');
    }

    if (phone.length === 0 || email.length === 0) {
      foundError = true;
      setEmailError('You must provide either email or phone.');
    } else if (email.length > 0 && email.indexOf('@') == -1) {
      foundError = true;
      setEmailError('Email must contain an @ sign.');
    } else {
      setEmailError('');
    }

    if (comment.length > 100) {
      foundError = true;
      setCommentError('Comment cannot exceed 100 characters.');
    } else {
      setCommentError('');
    }

    if (terms === false) {
      foundError = true;
      setTermError('You must accept Terms & Condiitions.');
    } else {
      setTermError('');
    }
  }

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  name="fullname"
                  onChange={(e) => {
                    setUsername(e.currentTarget.value);
                  }}
                  value={username}
                />
              </div>
              <small className="error">{usernameError}</small>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setPassword(e.currentTarget.value);
                  }}
                  value={password}
                />
              </div>
              <small className="error">{passwordError}</small>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  name="confirmpassword"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setConfirm(e.currentTarget.value);
                  }}
                  value={confirm}
                />
              </div>
              <small className="error">{confirmError}</small>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      name="email"
                      onChange={(e) => {
                        console.log(e.currentTarget.value);
                        setEmail(e.currentTarget.value);
                      }}
                      value={email}
                    />
                  </div>
                  <small className="error">{emailError}</small>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      name="phonenumber"
                      onChange={(e) => {
                        console.log(e.currentTarget.value);
                        setPhone(e.currentTarget.value);
                      }}
                      value={phone}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  name="comment"
                  onChange={(e) => {
                    console.log(e.currentTarget.value);
                    setComment(e.currentTarget.value);
                  }}
                  value={comment}
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {comment.length} / 100
                </small>

                <small className="error">{commentError}</small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                    name="terms"
                    onChange={() => {
                      setTerms(!terms);
                    }}
                    checked={terms}
                    value="terms"
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                  <small className="error">{termError}</small>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
