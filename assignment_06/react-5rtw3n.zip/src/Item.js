import React from 'react';

export default function Item(props) {
  return (
    <div className="product">
      <img src={props.src} alt={props.alt} />
      <div className="name">{props.name}</div>
      <div className="cost">{props.cost}</div>
    </div>
  );
}
