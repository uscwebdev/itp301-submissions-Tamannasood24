import React from 'react';
import { useState } from 'react';

export default function ItemButtons() {
  const [count, setCount] = useState(0);

  function handlePlusClick() {
    console.log('button clicked.');
    console.log(count);
    setCount(count + 1);
    console.log(count);
  }

  function handleMinusClick() {
    console.log('button clicked.');
    console.log(count);
    if (count > 0) {
      setCount(count - 1);
    }
  }

  return (
    <div className="buttons">
      <button id="plus" onClick={handlePlusClick}>
        +
      </button>
      <p id="counter">{count}</p>
      <button id="minus" onClick={handleMinusClick}>
        -
      </button>
    </div>
  );
}
