import React from 'react';
import Item from './Item.js';
import { createRoot } from 'react-dom/client';
import ItemButtons from './ItemButtons.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="header">
      <h1> Ice Cream Cart!</h1>
    </div>
    <div className="product">
      <Item
        src="https://static.vecteezy.com/system/resources/previews/019/607/024/original/ice-cream-graphic-clipart-design-free-png.png"
        alt="This is an image of a clipart ice cream cone."
        name="Ice Cream Cone"
        cost="$3.50"
      />
      <ItemButtons />
    </div>
    <div className="product">
      <Item
        src="https://www.specialedsimplified.com/wp-content/uploads/2020/07/products-ice_cream_sandwich.gif"
        alt="This is a clipart image of an ice cream sandwich."
        name="Ice Cream Sandwich"
        cost="$2.50"
      />
      <ItemButtons />
    </div>
    <div className="product">
      <Item
        src="https://cdn-icons-png.flaticon.com/512/938/938085.png"
        alt="This is a clipart image of an ice cream sorbet."
        name="Ice Cream Sorbet"
        cost="$3.00"
      />
      <ItemButtons />
    </div>
    <div className="product">
      <Item
        src="https://creazilla-store.fra1.digitaloceanspaces.com/cliparts/22979/popsicle-clipart-xl.png"
        alt="This is a clipart image of a popsicle."
        name="Popsicle"
        cost="$2.50"
      />
      <ItemButtons />
    </div>
  </React.StrictMode>
);
