import React from 'react';

export default function AugustButtons() {
  return (
    <div id="button_container">
      <button id="one">
        <img
          src="https://i.postimg.cc/9fWR7R5t/IMG-1547.jpg"
          alt="This is an image of people at dinner"
        />
      </button>
      <button id="two">
        {' '}
        <img
          src="https://i.postimg.cc/HnKX0p4W/IMG-1757.jpg"
          alt="This is a group image of people near a fountain."
        />{' '}
      </button>
      <button id="three">
        <img
          src="https://i.postimg.cc/Fsynr89d/IMG-5645.jpg"
          alt="This is an image of Tamanna and a puppy."
        />
      </button>
      <button id="four">
        <img
          src="https://i.postimg.cc/7PgN0zjj/IMG-1686.jpg"
          alt="This is an image of Tamanna and a friend."
        />{' '}
      </button>
      <button id="five">
        <img
          src="https://i.postimg.cc/ydxwWPfq/IMG-1811.jpg"
          alt="This is an image of Tamanna and her boyfriend."
        />
      </button>
      <div id="main_image">
        <img
          src="https://i.postimg.cc/9fWR7R5t/IMG-1547.jpg"
          alt="This is a selfie of a group of people at dinner. "
        />
        <p id="caption">
          This picture was taken on August, 19th 2023! The Saturday before
          school started. My hometown friends came to visit me on campus and say
          our goodbyes before school started. We went to Bacari, which is a
          iconic restaurant near the USC area!{' '}
        </p>
      </div>
    </div>
  );
}
