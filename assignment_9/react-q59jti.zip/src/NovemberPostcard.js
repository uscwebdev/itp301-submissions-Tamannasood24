import React from 'react';

export default function NovemberPostcard() {
  return (
    <div id="postcard_container">
      <div id="November_Intro">
        November 2023 has been really quick moving month! This month I
        celebrated Diwali (the biggest Hindu Festival of the Year!), played with
        Ozzie, and hung out with my friends!
      </div>
      <div className="Postcard">
        <img
          src="https://i.postimg.cc/fWVQz0f9/IMG-4477-2.jpg"
          alt="This is an image of Tamanna and her friend."
        />
        <p>
          November 3rd, 2023! On November 3rd, my club SCIA hosted our very
          first annual Diwali Party in Downtown! My bestfriend Rumaisa and I
          danced the night away and had a whole lot of fun with our friends. [I
          WANT TO MAKE THESE POSTCARDS FLIP]
        </p>
      </div>

      <div className="Postcard">
        <img
          src="https://i.postimg.cc/vBx50z5y/IMG-2724.jpg"
          alt="This is an image of Tamanna and her boyfriend."
        />
        <p>
          November 12rd, 2023! On November 12rd, my family hosted our own Diwali
          event! My entire family came and we ate alot of good food, had a alot
          of fun family time, played Diwali games, and lit sparklers. My
          boyfriend also came to my hometown to celebrate. [Will change these to
          components and make multiple]
        </p>
      </div>
    </div>
  );
}
