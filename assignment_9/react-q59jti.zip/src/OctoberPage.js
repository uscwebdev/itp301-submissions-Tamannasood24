import React from 'react';

export default function OctoberPage() {
  return (
    <div id="October_container">
      <div id="October_intro">
        <p>
          October was an overall great month where I felt the spooky vibes and
          finally started ingratiating myself back into school!{' '}
        </p>
      </div>
      <img
        src="https://i.postimg.cc/fbbVVF1T/IMG-2086.jpg"
        alt="This is an image of three dogs"
      />
      <div className="oct_captions">
        <p>
          {' '}
          October 9th, 2023! Puppy Party on the Village Lawn! This day was the
          first time we took out Ozzie to socialize with other puppies at USC!
          We all had a great time seeing all the dogs play with each other!
          (THIS WILL BE COLLAPSE TEXT)
        </p>
      </div>

      <img
        src="https://i.postimg.cc/qqpsZQzt/IMG-2297.jpg"
        alt="This is an image of an Indian wedding."
      />

<div className="oct_captions">
        <p>
          {' '}
          October 9th, 2023! Puppy Party on the Village Lawn! This day was the
          first time we took out Ozzie to socialize with other puppies at USC!
          We all had a great time seeing all the dogs play with each other!
          (THIS WILL BE COLLAPSE TEXT)
        </p>
      </div>


    </div>
  );
}
