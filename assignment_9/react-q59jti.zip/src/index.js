import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import AugustButtons from './AugustButtons.js';
import OctoberPage from './OctoberPage.js';
import NovemberPostcard from './NovemberPostcard.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="container">
      <h1>Tamanna's Senior Year!</h1>
      <p id="intro">
        Hi everyone! I'm Tamanna, a current senior studying Journalism and
        minoring in Documentary filmmaking and specializing in Web Development
        at USC! Welcome to my online time capsule where I will share and
        highlight some of my favorite and not so favorite moments from my last
        year in college! Quite honestly, I'm very sad that this is my last year
        in school because I started college during the pandemic and never got
        the traditional college experience. I hope by spotlighting and
        reminscing all of the good (and maybe some of the bad) times I have had
        this past semester, I can cherish all the memories I did have the
        pleasure of making!
      </p>

      <img
        id="big_first_pic"
        src="https://i.postimg.cc/mgPg9Yts/IMG-2510.jpg"
        alt="This is a picture of Tamanna and friends on Halloween."
      />
      <p>(It's me, Tamanna, in the middle!^^)</p>
      <div id="button_container">
        <button>August/September 2023</button>
        <button>October 2023</button>
        <button>November 2023</button>
      </div>
      <div id="Aug_Sept">
        <h1>August & September 2023</h1>
        <p id="aug_intro">
          August and September marks 'Back to School' season! During these
          months, I enjoyed football games, seeing friends I hadn't seen all
          summer, and getting used to being back in school!
        </p>
        <AugustButtons />
      </div>
      <div id="October">
        <h1>October 2023</h1>
        <OctoberPage />
      </div>

      <div id="November">
        <h1>November 2023</h1>
        <NovemberPostcard />
      </div>
    </div>
  </React.StrictMode>
);
